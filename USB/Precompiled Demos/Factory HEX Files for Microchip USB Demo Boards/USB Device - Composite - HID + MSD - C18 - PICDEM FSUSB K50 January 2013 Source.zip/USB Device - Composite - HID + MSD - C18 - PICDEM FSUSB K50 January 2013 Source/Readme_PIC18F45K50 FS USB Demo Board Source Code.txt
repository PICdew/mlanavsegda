This source code was used in generating the "picdemfsusb45K50.hex"
file.  This HID+MSD composite project was started from the HID+MSD composite
firmware example from the August 22, 2012 release of the Microchip Library of Applications.  A few modifications were made to make the
demo more interesting, and to allow for better testing of the board's features.

This source code is provided for reference purposes.  Please note however, that since this source
is an archive of the project used to create the
"picdemfsusb45K50.hex" file, this source code is not planned to get
updated in future releases of the Microchip Library of Applications.  If starting a new development project that will 
be similar to this project, it is suggested to consider using the latest demo firmware project(s) in the
Microchip Library of Applications, instead of this archive version.

The "picdemfsusb45K50.hex" was created by:

1.  Programming the PIC18F45K50 silicon with the HID bootloader (from the August 22, 2012 release of the Microchip Library of Applications) firmware.
2.  Using the HID bootloader to program the output hex file from the HID+MSD composite firmware
	included in this source archive.
3.  Allowing the HID+MSD composite firmware to run and enumerate once.
4.  Manually modifying the contents of the MSD drive volume by copying the "Readme.txt" and
	"getting_started_FS_USB_PIC18F45K50" files onto the drive using the Windows Explorer.
5.  Reading the entire memory contents out of flash using an ICSP(tm) programmer/debugger,
and then exporting the contents to the "picdemfsusb45K50.hex" file.
